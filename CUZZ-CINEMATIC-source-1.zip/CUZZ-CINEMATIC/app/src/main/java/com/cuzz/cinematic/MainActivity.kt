package com.cuzz.cinematic

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var recordButton: Button
    private lateinit var qualitySpinner: Spinner
    private lateinit var executor: ExecutorService
    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var frontCamera = false
    private var torchOn = false
    private var stabilizationRequested = true

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.CAMERA] == true) startCamera()
        else status.text = "Izin kamera diperlukan untuk memulai"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = Executors.newSingleThreadExecutor()
        buildInterface()
        val needed = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) startCamera()
        else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF08090B.toInt()) }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 12, 22, 12); setBackgroundColor(0x9908090B.toInt())
        }
        val brand = TextView(this).apply { text = "CUZZ  /  CINEMATIC"; textSize = 17f; setTextColor(0xFFD7B56D.toInt()); letterSpacing = .12f }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        status = TextView(this).apply { text = "MENYIAPKAN KAMERA"; textSize = 11f; setTextColor(-1) }
        top.addView(status)
        val topParams = FrameLayout.LayoutParams(-1, 58, Gravity.TOP)
        root.addView(top, topParams)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(16, 12, 16, 16); setBackgroundColor(0xDD08090B.toInt())
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, 8) }
        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1080p", "720p", "480p"))
        }
        controls.addView(label("RESOLUSI")); controls.addView(qualitySpinner, LinearLayout.LayoutParams(125, 46))
        controls.addView(space(12))
        val stab = button("STABILIZER: ON") { stabilizationRequested = !stabilizationRequested; it.text = if (stabilizationRequested) "STABILIZER: ON" else "STABILIZER: OFF"; startCamera() }
        controls.addView(stab)
        controls.addView(space(8))
        controls.addView(button("FLASH") { torchOn = !torchOn; camera?.cameraControl?.enableTorch(torchOn) })
        controls.addView(space(8))
        controls.addView(button("BALIK") { frontCamera = !frontCamera; startCamera() })
        bottom.addView(controls)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        recordButton = Button(this).apply { text = "●  MULAI REKAM"; textSize = 15f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB83B42.toInt())); setOnClickListener { toggleRecording() } }
        actions.addView(recordButton, LinearLayout.LayoutParams(210, 54))
        actions.addView(space(18))
        actions.addView(button("GALERI") { openGallery() })
        bottom.addView(actions)
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply { text = value; textSize = 10f; setTextColor(0xFFD7B56D.toInt()); setPadding(8, 0, 5, 0) }
    private fun space(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(width, 1) }
    private fun button(value: String, action: (Button) -> Unit) = Button(this).apply {
        text = value; textSize = 10f; isAllCaps = false; setTextColor(-1)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF292B30.toInt()))
        setOnClickListener { action(this) }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val selector = if (frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val previewBuilder = Preview.Builder()
                val extender = Camera2Interop.Extender(previewBuilder)
                if (stabilizationRequested) {
                    extender.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                    extender.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
                } else {
                    extender.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
                }
                val preview = previewBuilder.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val quality = when (qualitySpinner.selectedItemPosition) {
                    1 -> Quality.HD
                    2 -> Quality.SD
                    else -> Quality.FHD
                }
                val qualitySelector = QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                val recorder = Recorder.Builder().setQualitySelector(qualitySelector).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, videoCapture)
                status.text = if (stabilizationRequested) "STABILIZER DIMINTA • ${quality.name}" else "STABILIZER OFF • ${quality.name}"
                camera?.cameraControl?.enableTorch(torchOn && !frontCamera)
            } catch (e: Exception) { status.text = "Kamera tidak tersedia: ${e.localizedMessage}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleRecording() {
        val capture = videoCapture ?: run { status.text = "Kamera belum siap"; return }
        if (recording != null) { recording?.stop(); recording = null; recordButton.text = "●  MULAI REKAM"; return }
        val name = "CUZZ_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CUZZ CINEMATIC")
        }
        val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, options)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> { recordButton.text = "■  BERHENTI"; status.text = "SEDANG MEREKAM" }
                is VideoRecordEvent.Finalize -> {
                    recordButton.text = "●  MULAI REKAM"
                    status.text = if (!event.hasError()) "TERSIMPAN DI GALERI" else "GAGAL MENYIMPAN: ${event.error}"
                    recording = null
                }
            }
        }
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { status.text = "Aplikasi galeri tidak ditemukan" }
    }

    override fun onDestroy() {
        recording?.stop(); executor.shutdown(); super.onDestroy()
    }
}
