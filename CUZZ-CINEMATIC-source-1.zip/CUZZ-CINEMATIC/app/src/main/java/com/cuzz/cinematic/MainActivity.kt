
package com.cuzz.cinematic

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var shutter: FrameLayout
    private lateinit var shutterCore: View
    private lateinit var qualityText: TextView
    private lateinit var modeText: TextView

    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var imageCapture: ImageCapture? = null
    private var recording: Recording? = null

    private var frontCamera = false
    private var torchOn = false
    private var stabilizationOn = true
    private var eisSupported = false
    private var quality1080 = true
    private var currentMode = "VIDEO"

    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startCamera()
            } else {
                status.text = "IZIN KAMERA DIPERLUKAN"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        buildInterface()

        val permissions = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )

        if (Build.VERSION.SDK_INT <= 28) {
            permissions.add(
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }

        if (permissions.all {
                ContextCompat.checkSelfPermission(
                    this, it
                ) == PackageManager.PERMISSION_GRANTED
            }) {
            startCamera()
        } else {
            permissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun background(
        color: Int,
        radius: Float,
        stroke: Int = 0
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius.toInt()).toFloat()
            if (stroke > 0) {
                setStroke(dp(2), Color.WHITE)
            }
        }
    }

    private fun text(
        value: String,
        size: Float,
        color: Int = Color.WHITE
    ): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            typeface = Typeface.create(
                "sans-serif",
                Typeface.NORMAL
            )
        }
    }

    private fun buildInterface() {

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        // CAMERA PREVIEW
        previewView = PreviewView(this).apply {
            implementationMode =
                PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }

        root.addView(
            previewView,
            FrameLayout.LayoutParams(-1, -1)
        )

        // TOP BAR
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(0x55000000)
        }

        val flashButton = text("ϟ", 27f)
        top.addView(
            flashButton,
            LinearLayout.LayoutParams(dp(48), dp(48))
        )

        flashButton.setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(
                torchOn && !frontCamera
            )
            flashButton.alpha = if (torchOn) 1f else 0.55f
        }

        val spacer = View(this)
        top.addView(
            spacer,
            LinearLayout.LayoutParams(0, 1, 1f)
        )

        qualityText = text("4K 30", 13f).apply {
            setPadding(dp(13), dp(8), dp(13), dp(8))
            background = background(
                0x66000000,
                20f
            )
        }

        top.addView(qualityText)

        qualityText.setOnClickListener {
            if (recording != null) return@setOnClickListener

            quality1080 = !quality1080

            qualityText.text =
                if (quality1080) "1080P 30"
                else "720P 30"

            startCamera()
        }

        top.addView(
            View(this),
            LinearLayout.LayoutParams(dp(12), 1)
        )

        val settingsButton = text("⋯", 27f)
        top.addView(
            settingsButton,
            LinearLayout.LayoutParams(dp(45), dp(48))
        )

        settingsButton.setOnClickListener {
            stabilizationOn = !stabilizationOn
            startCamera()
        }

        root.addView(
            top,
            FrameLayout.LayoutParams(
                -1,
                dp(66),
                Gravity.TOP
            )
        )

        // STABILIZER STATUS
        status = text("MENYIAPKAN KAMERA", 11f).apply {
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = background(
                0x88000000.toInt(),
                18f
            )
        }

        root.addView(
            status,
            FrameLayout.LayoutParams(
                -2,
                -2,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply {
                topMargin = dp(78)
            }
        )

        // BOTTOM CAMERA PANEL
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(
                dp(12),
                dp(12),
                dp(12),
                dp(24)
            )
            setBackgroundColor(0x99000000.toInt())
        }

        // ZOOM SELECTOR
        val zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        listOf("0.5x", "1x", "2x").forEach { zoom ->
            val zoomButton = text(
                zoom,
                if (zoom == "1x") 16f else 13f,
                if (zoom == "1x") 0xFFFFD88A.toInt()
                else Color.WHITE
            )

            zoomButton.setPadding(
                dp(17), dp(12), dp(17), dp(12)
            )

            zoomRow.addView(zoomButton)

            zoomButton.setOnClickListener {
                val ratio = when (zoom) {
                    "0.5x" -> 0.5f
                    "2x" -> 2f
                    else -> 1f
                }

                setZoom(ratio)
            }
        }

        bottom.addView(zoomRow)

        // MODE SELECTOR
        val modes = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }

        listOf(
            "CINEMATIC",
            "VIDEO",
            "PHOTO"
        ).forEach { mode ->

            val item = text(
                mode,
                12f,
                if (mode == currentMode)
                    0xFFFFD88A.toInt()
                else
                    Color.WHITE
            )

            item.setPadding(
                dp(13), dp(10), dp(13), dp(10)
            )

            modes.addView(item)

            item.setOnClickListener {
                if (recording != null) return@setOnClickListener

                currentMode = mode

                for (i in 0 until modes.childCount) {
                    val child = modes.getChildAt(i) as TextView
                    child.setTextColor(
                        if (child.text == currentMode)
                            0xFFFFD88A.toInt()
                        else
                            Color.WHITE
                    )
                }

                status.text = when (mode) {
                    "CINEMATIC" ->
                        "CINEMATIC • TANPA BLUR KEDALAMAN"

                    "PHOTO" ->
                        "MODE FOTO"

                    else ->
                        "MODE VIDEO"
                }
            }
        }

        bottom.addView(modes)

        // SHUTTER ROW
        val shutterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val gallery = text("▣", 27f)
        shutterRow.addView(
            gallery,
            LinearLayout.LayoutParams(
                dp(65), dp(70)
            )
        )

        gallery.setOnClickListener {
            openGallery()
        }

        val shutterHolder = FrameLayout(this)

        shutter = FrameLayout(this).apply {
            background = background(
                Color.TRANSPARENT,
                50f,
                1
            )
        }

        shutterCore = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFFFF7E8.toInt())
            }
        }

        shutter.addView(
            shutterCore,
            FrameLayout.LayoutParams(
                dp(57),
                dp(57),
                Gravity.CENTER
            )
        )

        shutterHolder.addView(
            shutter,
            FrameLayout.LayoutParams(
                dp(76),
                dp(76),
                Gravity.CENTER
            )
        )

        shutterRow.addView(
            shutterHolder,
            LinearLayout.LayoutParams(
                dp(100),
                dp(82)
            )
        )

        shutter.setOnClickListener {
            if (currentMode == "PHOTO") {
                takePhoto()
            } else {
                toggleRecording()
            }
        }

        val flip = text("⟳", 32f)

        shutterRow.addView(
            flip,
            LinearLayout.LayoutParams(
                dp(65),
                dp(70)
            )
        )

        flip.setOnClickListener {
            if (recording != null) return@setOnClickListener

            frontCamera = !frontCamera
            torchOn = false
            startCamera()
        }

        bottom.addView(shutterRow)

        root.addView(
            bottom,
            FrameLayout.LayoutParams(
                -1,
                -2,
                Gravity.BOTTOM
            )
        )

        setContentView(root)
    }

    private fun setZoom(requested: Float) {
        val state = camera?.cameraInfo?.zoomState?.value
            ?: return

        val ratio = requested.coerceIn(
            state.minZoomRatio,
            state.maxZoomRatio
        )

        camera?.cameraControl?.setZoomRatio(ratio)
    }

    private fun startCamera() {

        val future =
            ProcessCameraProvider.getInstance(this)

        future.addListener({

            try {
                val provider = future.get()

                val selector =
                    if (frontCamera)
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    else
                        CameraSelector.DEFAULT_BACK_CAMERA

                val preview = Preview.Builder()
                    .build()
                    .also {
                        it.setSurfaceProvider(
                            previewView.surfaceProvider
                        )
                    }

                val cameraInfo =
                    provider.getCameraInfo(selector)

                val quality =
                    if (quality1080)
                        Quality.FHD
                    else
                        Quality.HD

                val qualitySelector = QualitySelector.from(
                    quality,
                    FallbackStrategy.lowerQualityOrHigherThan(
                        Quality.SD
                    )
                )

                val recorder = Recorder.Builder()
                    .setQualitySelector(qualitySelector)
                    .build()

                val capabilities =
                    Recorder.getVideoCapabilities(cameraInfo)

                eisSupported =
                    capabilities.isStabilizationSupported

                val enableEis =
                    stabilizationOn && eisSupported

                val video = VideoCapture.Builder(recorder)
                    .setVideoStabilizationEnabled(enableEis)
                    .build()

                val photo = ImageCapture.Builder()
                    .setCaptureMode(
                        ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                    )
                    .build()

                provider.unbindAll()

                camera = provider.bindToLifecycle(
                    this,
                    selector,
                    preview,
                    video,
                    photo
                )

                videoCapture = video
                imageCapture = photo

                camera?.cameraControl?.enableTorch(
                    torchOn && !frontCamera
                )

                status.text = when {
                    enableEis ->
                        "EIS AKTIF"

                    stabilizationOn ->
                        "EIS TIDAK DIDUKUNG"

                    else ->
                        "STABILIZER OFF"
                }

            } catch (e: Exception) {
                status.text =
                    "KAMERA ERROR: ${e.localizedMessage}"
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleRecording() {

        if (recording != null) {
            recording?.stop()
            return
        }

        val capture = videoCapture ?: return

        val filename =
            "CUZZ_${SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(System.currentTimeMillis())}.mp4"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")

            if (Build.VERSION.SDK_INT >= 29) {
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "Movies/CUZZ CINEMATIC"
                )
            }
        }

        val output = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )
            .setContentValues(values)
            .build()

        var pending =
            capture.output.prepareRecording(this, output)

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            pending = pending.withAudioEnabled()
        }

        recording = pending.start(
            ContextCompat.getMainExecutor(this)
        ) { event ->

            when (event) {

                is VideoRecordEvent.Start -> {
                    status.text = "● MEREKAM"
                    shutterCore.background =
                        background(0xFFE53935.toInt(), 8f)
                }

                is VideoRecordEvent.Finalize -> {
                    recording = null

                    shutterCore.background =
                        GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(0xFFFFF7E8.toInt())
                        }

                    status.text =
                        if (!event.hasError())
                            "VIDEO TERSIMPAN"
                        else
                            "GAGAL: ${event.error}"
                }
            }
        }
    }

    private fun takePhoto() {

        val capture = imageCapture ?: return

        val filename =
            "CUZZ_PHOTO_${System.currentTimeMillis()}.jpg"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")

            if (Build.VERSION.SDK_INT >= 29) {
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "Pictures/CUZZ CINEMATIC"
                )
            }
        }

        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()

        capture.takePicture(
            options,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {

                override fun onImageSaved(
                    result: ImageCapture.OutputFileResults
                ) {
                    status.text = "FOTO TERSIMPAN"
                }

                override fun onError(
                    exception: ImageCaptureException
                ) {
                    status.text =
                        "FOTO GAGAL: ${exception.message}"
                }
            }
        )
    }

    private fun openGallery() {
        val intent = android.content.Intent(
            android.content.Intent.ACTION_VIEW
        ).apply {
            setDataAndType(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                "video/*"
            )
            addFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            )
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            status.text = "GALERI TIDAK DITEMUKAN"
        }
    }

    override fun onDestroy() {
        recording?.stop()
        super.onDestroy()
    }
}
